"""가상 교육 데이터와 계산표 생성. 실제 고객/거래 데이터가 아니다. 표준 라이브러리만 사용."""
from pathlib import Path
import csv, json, calendar

ROOT = Path(__file__).resolve().parent
LABEL = '가상 교육 데이터; 실제 계약·매출·투자 실적 아님'
P = dict(supply=12500, recovery=12250, washed=12000, price=500,
         rental_per_supply=80, wash_per_washed=180, logistics_per_order=600000,
         counting_report_per_order=240000, lost_per_item=600, rejected_per_item=200)

def order_calc(s=12500, r=12250, w=12000, price=500):
    assert 0 <= w <= r <= s
    costs = dict(rental=s*80, washing=w*180, logistics=600000,
                 counting_report=240000, lost=(s-r)*600, rejected=(r-w)*200)
    revenue = w*price
    cost = sum(costs.values())
    return dict(supply=s,recovery=r,washed=w,billed=w,revenue=revenue,cost=cost,
                contribution=revenue-cost,margin=(revenue-cost)/revenue,**costs)

def csv_write(name, rows):
    with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)

base=order_calc()
customer_ids=[f'SIM-C{i:02d}' for i in range(1,13)]
orders_per_customer=[3]*6+[4]*2+[1]*4
queue=customer_ids.copy()
for round_no in range(1,4):
    queue += [c for c,n in zip(customer_ids,orders_per_customer) if n>round_no]
assert len(queue)==30
orders=[]; idx=0
for month,n in zip(range(4,10),[2,3,4,5,7,9]):
    for j in range(n):
        date=f'2026-{month:02d}-{min(3+j*2,25):02d}'
        orders.append(dict(data_status=LABEL,id=f'H-ORD{idx+1:03d}',customer=queue[idx],
                           service_date=date,**base))
        idx+=1
csv_write('가상_발주30건.csv',orders)
customers=[dict(data_status=LABEL,customer=c,segment='지역 행사 운영사' if i<8 else '대학·기업 행사 대행사',
                orders=n,repeat_customer=n>=2,revenue=n*base['revenue'])
           for i,(c,n) in enumerate(zip(customer_ids,orders_per_customer))]
csv_write('가상_고객12곳.csv',customers)
interviews=[]
for i in range(1,17):
    interviews.append(dict(data_status=LABEL,id=f'H-INT{i:02d}',customer=f'SIM-C{i:02d}',
        problem_handoffs=i<=12,needs_quantity_report=i<=10,needs_return_staff=i<=9,
        paid_conversion=i<=12,reason='가상 견적·업무 범위에 동의' if i<=12 else '가격·일정 또는 기존 거래처 유지로 보류'))
csv_write('가상_고객면담16건.csv',interviews)
q4_orders=[4,4,4]; cash=60000000; prev_revenue=54000000; q4=[]
for month,n in zip(range(10,13),q4_orders):
    rev=n*base['revenue']; receipts=(rev+prev_revenue)/2
    cash += receipts-n*base['cost']-12000000
    q4.append(dict(data_status=LABEL,month=f'2026-{month}',orders=n,revenue=rev,receipts=receipts,
                   direct_cost=n*base['cost'],opex=12000000,end_cash=cash,end_receivables=rev/2))
    prev_revenue=rev
csv_write('2026Q4_가정현금연결.csv',q4)
assert cash==60600000 and prev_revenue/2==12000000

monthly_2027=[4,4,6,8,10,12,10,8,12,12,8,6]
assert sum(monthly_2027)==100
def forecast(multiplier=1,price=500):
    # Fractional orders in demand sensitivity are expected values, not executed contracts.
    cash=60600000+300000000; previous_revenue=24000000
    rows=[]; assets=[]
    for i in range(18):
        year=2027+i//12; month=i%12+1
        nominal=monthly_2027[month-1]*(1 if year==2027 else 2)
        n=nominal*multiplier; unit=order_calc(price=price)
        rev=n*unit['revenue']; direct=n*unit['cost']; opex=15000000 if year==2027 else 20000000
        capex={0:60000000,3:50000000,12:30000000}.get(i,0)
        if capex: assets.append(capex)
        depreciation=sum(assets)/60
        receipts=(rev+previous_revenue)/2
        start=cash; cash+=receipts-direct-opex-capex
        capacity=120000 if i<3 else (180000 if i<12 else 300000)
        assert n*12000<=capacity
        rows.append(dict(data_status=LABEL,month=f'{year}-{month:02d}',orders=n,
            supplied=n*12500,recovered=n*12250,washed=n*12000,billed=n*12000,
            capacity=capacity,utilization=n*12000/capacity,revenue=rev,direct_cost=direct,
            contribution=rev-direct,opex=opex,ebitda=rev-direct-opex,
            depreciation=depreciation,ebit=rev-direct-opex-depreciation,
            receipts=receipts,capex=capex,start_cash=start,end_cash=cash,end_receivables=rev/2))
        previous_revenue=rev
    return rows

forecast_rows=forecast();csv_write('18개월_가정재무현금흐름.csv',forecast_rows)
annual=[]
for year,n,opex,dep,capex,capacity in [(2027,100,180000000,19500000,110000000,180000),
 (2028,200,240000000,28000000,30000000,300000),(2029,400,360000000,60000000,160000000,600000)]:
    rev=n*base['revenue'];cogs=n*base['cost']
    annual.append(dict(data_status=LABEL,year=year,customers={2027:25,2028:40,2029:50}[year],
                      orders=n,billed=n*12000,revenue=rev,direct_cost=cogs,
                      contribution=rev-cogs,opex=opex,ebitda=rev-cogs-opex,
                      depreciation=dep,ebit=rev-cogs-opex-dep,capex=capex,
                      year_end_monthly_capacity=capacity))
csv_write('3개년_가정손익.csv',annual)
sens=[]
for name,mult,price in [('기준',1,500),('수요75%',.75,500),('수요50%',.5,500),('단가450원',1,450)]:
    rows=forecast(mult,price)
    sens.append(dict(data_status=LABEL,scenario=name,min_cash=min(x['end_cash'] for x in rows),
                     ending_cash=rows[-1]['end_cash'],ebitda_18m=sum(x['ebitda'] for x in rows),
                     min_cash_month=min(rows,key=lambda x:x['end_cash'])['month']))
csv_write('현금_민감도.csv',sens)
returns=[]
for name,r,w in [('회수98%',12250,12000),('회수95%',11875,round(11875*48/49)),('회수90%',11250,round(11250*48/49))]:
    returns.append(dict(data_status=LABEL,scenario=name,**order_calc(r=r,w=w)))
csv_write('회수율_민감도.csv',returns)
metrics=dict(data_status=LABEL,order=base,history=dict(orders=30,customers=12,repeat_customers=8,
    supply=375000,recovery=367500,washed=360000,revenue=180000000,direct_cost=126000000,
    contribution=54000000,opex=72000000,ebitda=-18000000,initial_equity=105000000,
    sep_cash=60000000,sep_ar=27000000),
    opening_cash_2027=60600000,opening_ar_2027=12000000,investment=300000000,
    pre_money=1200000000,post_money=1500000000,new_ownership=.2,
    illustrative_event_model=dict(status="내부 행사 교육 산식; 현재 IR의 TAM/SAM 아님",nationwide_event_scenario=1000*20*12000*500,regional_event_scenario=200*12*12000*500,revenue_target_2027=25*4*12000*500),
    annual=annual,cash_sensitivity=sens,return_sensitivity=returns)
(ROOT/'모델요약.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
assert sum(o['revenue'] for o in orders)==180000000
assert sum(o['orders'] for o in customers)==30
assert sum(x['revenue'] for x in forecast_rows[:12])==annual[0]['revenue']
assert forecast_rows[-1]['end_cash']==199000000
print(json.dumps(dict(order=base,annual=annual,sensitivity=sens,returns=returns),ensure_ascii=False,indent=2))
